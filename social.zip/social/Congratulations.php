<?php
$message="<h1>Congratulatioins!!</h1> You're registered with Avigabso. An Email has been sent to your email address. Please follow the instructions to activate the account.";
print($message);
?>
