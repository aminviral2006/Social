<a href="/index.php" title="home"><?php echo HOME; ?> |</a>
<a href="/faq.php" title="faq"><?php echo FAQ; ?> |</a>
<a href="/aboutus.php" title="about us"><?php echo ABOUT_US; ?> |</a>
<a href="/privacy.php" title="privacy policy"><?php echo PRAVACY_POLICY; ?> |</a>
<a href="/terms.php" title="term and conditions"><?php echo TERMS_AND_CONDITIONS; ?> |</a>
<!--<a href="#" title="contact us">צור קשר |</a>--> <a href="http://social.aminhospital.com/rss.xml" title="rss feed"><?php echo RSS_FEED; ?> </a><br/>
Copyright &copy; thebesthing.il.
<!--<script type="text/javascript" src="http://shots.snap.com/ss/595db0366a7babf0a4d9a7d41df86a2b/snap_shots.js"></script>-->