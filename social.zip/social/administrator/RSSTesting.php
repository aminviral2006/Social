<?php
include_once '../commoninclude.php';
$objPlStuff=new PlStuff();
$output=$objPlStuff->PlRssFeedForLatestStuffOnHomePage();

?>
